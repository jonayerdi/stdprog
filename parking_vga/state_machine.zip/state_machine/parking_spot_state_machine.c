/*
 * parking_spot_state_machine.c
 *
 *  Created on: 9 Jan 2018
 *      Author: Jon Ayerdi
 */

#include "domain/parking_spot_state_machine.h"

#include <string.h> /* memcpy */

#include "io/memory.h"
#include "io/gpio.h"

#include "lib/clock.h"

#define PARKING_SPOT_STATE_MACHINE_STATE_UNKNOWN \
{ \
	.controles = NULL, \
	.transiciones = \
		{ \
			{ \
				.evento = parking_spot_state_machine_is_free, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_free \
			}, \
			{ \
				.evento = parking_spot_state_machine_is_taken, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_taken \
			} \
		}, \
	.transiciones_count = 2 \
}

#define PARKING_SPOT_STATE_MACHINE_STATE_FREE \
{ \
	.controles = NULL, \
	.transiciones = \
		{ \
			{ \
				.evento = parking_spot_state_machine_is_taken, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_taking \
			} \
		}, \
	.transiciones_count = 1 \
}

#define PARKING_SPOT_STATE_MACHINE_STATE_FREEING \
{ \
	.controles = NULL, \
	.transiciones = \
		{ \
			{ \
				.evento = parking_spot_state_machine_is_taken, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_taken \
			}, \
			{ \
				.evento = parking_spot_state_machine_timeout_elapsed, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_free \
			} \
		}, \
	.transiciones_count = 2 \
}

#define PARKING_SPOT_STATE_MACHINE_STATE_TAKEN \
{ \
	.controles = NULL, \
	.transiciones = \
		{ \
			{ \
				.evento = parking_spot_state_machine_is_free, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_freeing \
			} \
		}, \
	.transiciones_count = 1 \
}

#define PARKING_SPOT_STATE_MACHINE_STATE_TAKING \
{ \
	.controles = NULL, \
	.transiciones = \
		{ \
			{ \
				.evento = parking_spot_state_machine_is_free, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_free \
			}, \
			{ \
				.evento = parking_spot_state_machine_timeout_elapsed, \
				.accion = parking_spot_state_machine_transition_action, \
				.estado_destino = parking_state_taken \
			} \
		}, \
	.transiciones_count = 2 \
}

#define PARKING_SPOT_STATE_MACHINE_STATES \
{ \
	PARKING_SPOT_STATE_MACHINE_STATE_UNKNOWN, \
	PARKING_SPOT_STATE_MACHINE_STATE_FREE, \
	PARKING_SPOT_STATE_MACHINE_STATE_FREEING, \
	PARKING_SPOT_STATE_MACHINE_STATE_TAKEN, \
	PARKING_SPOT_STATE_MACHINE_STATE_TAKING \
}

#define PARKING_SPOT_STATE_MACHINE(CONTEXT) \
{ \
		.estado_actual = parking_state_unknown, \
		.StopCond = parking_spot_state_machine_stop_condition, \
		.estados = PARKING_SPOT_STATE_MACHINE_STATES, \
		.estados_count = 5, \
		.contexto = (CONTEXT) \
}

BOOLEAN parking_spot_state_machine_stop_condition(void *context)
{
	parking_spot_state_machine_context_t *parking_context = (parking_spot_state_machine_context_t *)context;
	return parking_context->spot->mode == parking_spot_mode_forced ? TRUE : FALSE;
}
void parking_spot_state_machine_transition_action(void *context)
{
	parking_spot_state_machine_context_t *parking_context = (parking_spot_state_machine_context_t *)context;
	parking_context->spot->timestamp = parking_context->parking->time;
}
BOOLEAN parking_spot_state_machine_is_free(void *context)
{
	parking_spot_state_machine_context_t *parking_context = (parking_spot_state_machine_context_t *)context;
	return (gpio_get(parking_context->spot->input_source) == GPIO_VALUE_FREE) ? TRUE : FALSE;
}
BOOLEAN parking_spot_state_machine_is_taken(void *context)
{
	parking_spot_state_machine_context_t *parking_context = (parking_spot_state_machine_context_t *)context;
	return (gpio_get(parking_context->spot->input_source) == GPIO_VALUE_TAKEN) ? TRUE : FALSE;
}
BOOLEAN parking_spot_state_machine_timeout_elapsed(void *context)
{
	parking_spot_state_machine_context_t *parking_context = (parking_spot_state_machine_context_t *)context;
	return (CLOCK_DIFF_SECONDS(parking_context->spot->timestamp, parking_context->parking->time) > TIMEOUT_TRANSITION) ? TRUE : FALSE;
}

TS_MACHINE *parking_spot_create_state_machine(parking_t *parking, parking_spot_t * spot)
{
	TS_MACHINE *allocated_machine = (TS_MACHINE *)memory_allocate(sizeof(TS_MACHINE));
	if(allocated_machine == NULL)
		return NULL;
	parking_spot_state_machine_context_t *parking_context = (parking_spot_state_machine_context_t *)memory_allocate(sizeof(parking_spot_state_machine_context_t));
	if(parking_context == NULL)
	{
		memory_free(allocated_machine);
		return NULL;
	}
	TS_MACHINE state_machine = PARKING_SPOT_STATE_MACHINE(parking_context);
	allocated_machine->StopCond = state_machine.StopCond;
	allocated_machine->contexto = state_machine.contexto;
	allocated_machine->estado_actual = state_machine.estado_actual;
	allocated_machine->estados_count = state_machine.estados_count;
	allocated_machine->estados = (TS_ESTADO *)memory_allocate(sizeof(TS_ESTADO) * allocated_machine->estados_count);
	if(allocated_machine->estados == NULL)
	{
		memory_free(parking_context);
		memory_free(allocated_machine);
		return NULL;
	}
	for(size_t i = 0 ; i < state_machine.estados_count ; i++)
	{
		allocated_machine->estados[i].controles = state_machine.estados[i].controles;
		allocated_machine->estados[i].transiciones_count = state_machine.estados[i].transiciones_count;
		allocated_machine->estados[i].transiciones = (TS_TRANS *)memory_allocate(sizeof(TS_TRANS) * allocated_machine->estados[i].transiciones_count);
		if(allocated_machine->estados[i].transiciones == NULL)
		{
			for(size_t j = 0 ; j < i ; j++)
				memory_free(allocated_machine->estados[i].transiciones);
			memory_free(allocated_machine->estados);
			memory_free(parking_context);
			memory_free(allocated_machine);
		}
		for(size_t j = 0 ; j < state_machine.estados[i].transiciones_count ; j++)
		{
			allocated_machine->estados[i].transiciones[j].accion = state_machine.estados[i].transiciones[j].accion;
			allocated_machine->estados[i].transiciones[j].estado_destino = state_machine.estados[i].transiciones[j].estado_destino;
			allocated_machine->estados[i].transiciones[j].evento = state_machine.estados[i].transiciones[j].evento;
		}
	}
	return allocated_machine;
}

void parking_spot_destroy_state_machine(TS_MACHINE *state_machine)
{
	for(size_t i = 0 ; i < state_machine->estados_count ; i++)
		memory_free(state_machine->estados[i].transiciones);
	memory_free(state_machine->estados);
	memory_free(state_machine->contexto);
	memory_free(state_machine);
}
